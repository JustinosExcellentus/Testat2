package Testat2;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;


//Grafikkomponente des Fensters

public class Draw extends JPanel {


    //Methode, um zu bestimmen, ob ein String in ein Integer konvertiert werden kann
    public static boolean isInteger(String zahl){
        return zahl.matches("[0-9]+");


    }
    //Methode, um zu bestimmen, ob ein String in ein Double konvertiert werden kann

    public static boolean isDouble(String zahl){
        return (zahl.matches("([0-9]*)\\.([0-9]*)") || isInteger(zahl));

    }




    public Draw(){
        init();
    }


//Initialisiert Textfelder, Labels und weitere Variablen
    JTextField eingabeKapital = new JTextField("" , 3);
    JTextField eingabeJahre = new JTextField("" , 3);
    JTextField eingabeZinssatz = new JTextField("" , 3);


    Label labelKapital = new Label("Kapital: ");
    Label labelJahre = new Label("Jahre: ");
    Label labelZinssatz = new Label("Zinssatz: ");

    JButton jb1 = new JButton("Kapital berechnen");
    Label ergebnis = new Label("Ergebnis:");


  

    ActionListener actionListener = new ActionListener() {
        @Override

        //Erstellt einen ActionListener, der auf ein ActionEvent e reagiert
        public void actionPerformed(ActionEvent e) {
            if (e.getSource() == jb1) {// Falls das Event vom Button ausgeloest wurden ist


                //Wenn in einem Feld nichts eingegeben worden ist
                if(eingabeKapital.getText().equals("") || eingabeJahre.equals("") || eingabeZinssatz.getText().equals("")){
                    JOptionPane.showMessageDialog(null, "Keine Zahl wurde eingegeben","Warning", JOptionPane.WARNING_MESSAGE);
                    return;


                    //Wenn in einem Feld etwas anderes als eine Zahl eingegeben worden ist
                } else if(!isDouble(eingabeKapital.getText()) || !isInteger(eingabeJahre.getText()) || !isDouble(eingabeZinssatz.getText())){
                    System.out.println(!isDouble(eingabeKapital.getText()) + " " + !isInteger(eingabeJahre.getText()) + " " + !isDouble(eingabeZinssatz.getText()));

                    JOptionPane.showMessageDialog(null, "Es wurde etwas anderes als eine Zahl eingegeben!","Warning", JOptionPane.WARNING_MESSAGE);
                    return;


                } else {

                    //Falls ein illegaler Wert eingegeben wird (Jahre oder Kapital negativ)

                    if(Double.parseDouble(eingabeKapital.getText()) <0 || Integer.parseInt(eingabeJahre.getText())< 0){
                        JOptionPane.showMessageDialog(null, "Falscher Wertebereich","Warning", JOptionPane.WARNING_MESSAGE);
                        return;
                        //Nicht-reale Werte
                    } else{

                        //Ausgabe des Ergebnises auf 2 Nachkommastellen auf dem Label ergebnis


                        ergebnis.setText("Ergebnis: "+ String.format("%.2f",main.verzinse(Double.parseDouble(eingabeKapital.getText()), Integer.parseInt(eingabeJahre.getText()), Double.parseDouble(eingabeZinssatz.getText()))));

                        //Ausgabe
                    }

                }


            }
        }

    };




    //Fügt dem Panel alle Objekte hinzu
    protected void init(){






        jb1.addActionListener(actionListener);




        this.add(jb1);



        this.add(eingabeKapital);
        this.add(eingabeJahre);
        this.add(eingabeZinssatz);

        this.add(labelKapital);
        this.add(labelJahre);
        this.add(labelZinssatz);

        this.add(ergebnis);



    }

    
    //Zeichnet die Objekte auf das Panel

    protected void paintComponent(Graphics g) {


        labelKapital.setBounds(25, 200, 60, 20);

        labelJahre.setBounds(25, 225, 60, 20);
        labelZinssatz.setBounds(25, 250, 60, 20);

        eingabeKapital.setBounds(100,200, 120, 20);
        eingabeJahre.setBounds(100,225, 120, 20);
        eingabeZinssatz.setBounds(100, 250, 120,20);


        jb1.setBounds(75,300, 120, 20);
        ergebnis.setBounds(25,330, 160, 20);



        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
















    }

}
