package Testat2;

public class main {
    public static void main(String[] args){
        System.out.println(verzinse(1000, 1, 5));

        System.out.println(verzinse(1000, 2, 5));
        //Ein Fenster wird zur grafischen Darstellung erstellt.
        Window window = new Window();


    }



    //Methode nimmt als Parameter ein Kapital:double, Jahre:int und einen Zinsssatz:double, und gibt am Ende die Verzinsung des Kapitals k über n Jahre  mit dem Prozentsatz p zurück
    public static double verzinse(double kapital, int jahre, double zinssatz){
        //Wenn es weniger oder gleich 0 Jahre ist, ist entweder ein falscher Wert eingegeben worden, oder die Verzinsung wurde für alle Jahre n berechnet, in dem Fall wird das Kapital zurückgegeben
        if(jahre <= 0){
            return kapital;
        } else{
            //Berechnet das Kapital des nächsten Jahres mit untenstehender Formel für die Zinsberechnung, dadurch nimmt es ein Jahr ab, und der Zinssatz bleibt gleich
            return verzinse(kapital*(1+(zinssatz/100)), jahre-1, zinssatz);


        }
    }
}
