package Testat2;

import javax.swing.*;
import java.awt.*;

public class Window extends JFrame {
    JFrame jf;
    Draw draw;
    public Window(){
        create();
    }

    public void create(){
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        jf = new JFrame();
        Draw draw = new Draw();

        jf.setBounds(10, 10, 300,600);
        jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        jf.setVisible(true);
        jf.setResizable(false);
        jf.add(draw);
    }
}